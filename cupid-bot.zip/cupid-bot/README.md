# Cupid Bot

Bot privado de WhatsApp para um único grupo, com comandos de casal.

## Requisitos
- Node.js 20 ou superior
- Um número de WhatsApp dedicado/recomendado para o bot
- Computador ou servidor ligado enquanto o bot estiver em uso

## Instalação
1. Instale o Node.js.
2. Extraia esta pasta.
3. Abra o terminal dentro da pasta e execute:
   ```bash
   npm install
   ```
4. Copie `.env.example` para `.env`.
5. Execute:
   ```bash
   npm start
   ```
6. Escaneie o QR Code em WhatsApp > Aparelhos conectados.
7. Envie uma mensagem no grupo desejado. O terminal mostrará o ID do grupo.
8. Pare o bot (`Ctrl+C`), coloque o ID em `ALLOWED_GROUP_JID` no `.env` e execute `npm start` novamente.

## Personalização
- `PARTNER_ONE` e `PARTNER_TWO`: nomes exibidos.
- `RELATIONSHIP_DATE`: data de início no formato `AAAA-MM-DD`.
- O bot só responde no grupo cujo ID estiver em `ALLOWED_GROUP_JID`.
- Comandos começam com `!`: `!menu`, `!pergunta`, `!amor`, `!dias`, `!roleta`, `!sobre`.

## Importante
Este projeto usa Baileys, uma biblioteca não oficial que automatiza o WhatsApp Web. Isso pode violar os termos do WhatsApp e resultar em desconexão ou restrição da conta. Use por sua conta e risco, sem spam, e prefira um número separado. Não compartilhe a pasta `auth_info`: ela contém credenciais da sessão.
