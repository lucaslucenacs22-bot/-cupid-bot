import 'dotenv/config';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} from '@whiskeysockets/baileys';
import qrcode from 'qrcode-terminal';
import fs from 'node:fs';

const GROUP_ID = process.env.ALLOWED_GROUP_JID?.trim();
const ONE = process.env.PARTNER_ONE || 'Você';
const TWO = process.env.PARTNER_TWO || 'Sua namorada';
const DATE = process.env.RELATIONSHIP_DATE;
const AUTH_DIR = 'auth_info';

const questions = [
  'Qual foi a primeira coisa que chamou sua atenção na outra pessoa?',
  'Qual seria o encontro perfeito para vocês?',
  'Que música lembra o relacionamento de vocês?',
  'Qual mania da outra pessoa você acha engraçada?',
  'Se pudessem viajar agora, para onde iriam?',
  'Qual memória de vocês merece virar um filme?',
  'Quem demora mais para escolher o que comer?',
  'Qual foi um momento em que você se sentiu muito amado(a)?'
];

function daysTogether() {
  if (!DATE) return null;
  const start = new Date(`${DATE}T00:00:00`);
  if (Number.isNaN(start.getTime())) return null;
  return Math.max(0, Math.floor((Date.now() - start.getTime()) / 86400000));
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    browser: ['Cupid Bot', 'Chrome', '1.0.0']
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log('\nEscaneie este QR Code com o WhatsApp que vai hospedar o bot:');
      qrcode.generate(qr, { small: true });
    }
    if (connection === 'open') console.log('Cupid Bot conectado.');
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) startBot();
      else console.log('Sessão encerrada. Apague auth_info e conecte novamente.');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      const jid = msg.key.remoteJid;
      if (!jid?.endsWith('@g.us')) continue;

      // Sem grupo configurado, apenas mostra o ID para você copiar ao .env.
      if (!GROUP_ID) {
        console.log(`Grupo detectado: ${jid}. Coloque esse ID em ALLOWED_GROUP_JID no .env.`);
        continue;
      }
      if (jid !== GROUP_ID) continue;

      const body = msg.message.conversation
        || msg.message.extendedTextMessage?.text
        || msg.message.imageMessage?.caption
        || '';
      const command = body.trim().toLowerCase();
      if (!command.startsWith('!')) continue;

      let reply = '';
      if (command === '!menu' || command === '!ajuda') {
        reply = `💘 *CUPID BOT*\\n\\n!menu - ver comandos\\n!pergunta - pergunta para vocês responderem\\n!amor - mensagem aleatória\\n!dias - dias desde o início do namoro\\n!roleta - ideia aleatória de encontro\\n!sobre - quem criou este bot`;
      } else if (command === '!pergunta') {
        reply = `💬 *Pergunta para o casal:*\\n${questions[Math.floor(Math.random() * questions.length)]}`;
      } else if (command === '!amor') {
        const lines = [
          'Lembrete: relacionamento também é feito das pequenas coisas. Não economizem carinho. ❤️',
          'Missão de hoje: cada um falar uma coisa que admira no outro.',
          'Pausa obrigatória para mandar um carinho para quem está do outro lado. 💗',
          'Vocês são um time. Até para decidir o lanche.'
        ];
        reply = lines[Math.floor(Math.random() * lines.length)];
      } else if (command === '!dias') {
        const days = daysTogether();
        reply = days === null
          ? 'Configure RELATIONSHIP_DATE no arquivo .env usando AAAA-MM-DD.'
          : `❤️ ${ONE} e ${TWO}: ${days} dias de história até hoje.`;
      } else if (command === '!roleta') {
        const ideas = [
          'Noite de filme com lanchinho.',
          'Cada um escolhe uma música e explica o motivo.',
          'Fazer uma receita juntos.',
          'Passeio sem destino definido.',
          'Noite de jogos ou perguntas.',
          'Recriar o primeiro encontro de vocês.'
        ];
        reply = `🎲 *A roleta escolheu:* ${ideas[Math.floor(Math.random() * ideas.length)]}`;
      } else if (command === '!sobre') {
        reply = 'Sou o Cupid Bot, um bot privado feito para este grupo. 💘';
      }

      if (reply) {
        await sock.sendMessage(jid, { text: reply }, { quoted: msg });
      }
    }
  });
}

startBot().catch(err => {
  console.error('Erro ao iniciar o bot:', err);
  process.exit(1);
});
